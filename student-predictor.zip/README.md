# Student Predictor (Performance Prediction System)

A web-based Student Management and Performance Predictor project built using Python and Django. It predicts whether a student will Pass, Fail, or is At-Risk, based on their attendance, study hours, and academic marks.

---

## How to Run on any Laptop (First Time Setup)

Apne system ya kisi bhi naye laptop par is project ko run karne ke liye neeche diye gaye step-by-step steps follow karein:

### Step 1: Install Python
Ensure Python is installed on the laptop. If not, download and install it from [python.org](https://www.python.org/downloads/). (Make sure to check "Add Python to PATH" during installation).

### Step 2: Open Terminal / Command Prompt
Project folder ko extract karein. Folder ke andar jaakar search bar mein `cmd` likh kar Enter dabein ya Command Prompt open karke is path par navigate karein:
```bash
cd path/to/student-predictor
```

### Step 3: Create a Virtual Environment (Recommended)
Laptop par isolated environments ke liye virtual environment banayein:
```bash
python -m venv venv
```

**Activate the Virtual Environment:**
* **Windows:**
  ```bash
  venv\Scripts\activate
  ```
* **macOS / Linux:**
  ```bash
  source venv/bin/activate
  ```

### Step 4: Install Required Packages
Required packages aur Django install karne ke liye run karein:
```bash
pip install -r requirements.txt
```
*(Note: requirements.txt mein sirf basic configurations hain. Django framework mandatory hai, baaki machine learning libraries optional hain aur project unke bina bhi perfectly rules-based fallback par chalta hai).*

### Step 5: Run the Development Server
Project ko local server par chalane ke liye run karein:
```bash
python manage.py runserver
```

### Step 6: Access the App
Apne browser mein ye address open karein:
```
http://127.0.0.1:8000/
```

---

## Pre-configured Admin Login Details
Aapko database migrations run karne ya superuser banane ki zaroorat nahi hai (yeh already database mein created hai). 

* **Admin Username:** `admin`
* **Password:** `admin123`

*(Aap Admin area ko access karne ke liye http://127.0.0.1:8000/admin/ par ja sakte hain)*
